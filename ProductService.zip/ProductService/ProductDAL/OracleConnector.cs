﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDAL
{
    public class OracleConnector
    {
        public static DataTable GetProducts()
        {
           
            using (OracleConnection con = OracleHelper.getConnection())
            {
                con.Open();
                String sql = "select * from cont_product";
                OracleCommand cmd = new OracleCommand(sql, con);
                cmd.CommandType = CommandType.Text;
                OracleDataReader dr = cmd.ExecuteReader();
                //OracleDataAdapter oda = new OracleDataAdapter(cmd);
                DataTable dt = new DataTable("product");
              //  long size = dr.RowSize;
                dt.Load(dr);
                return dt;
            }
        }

        

                
        
    }
}
