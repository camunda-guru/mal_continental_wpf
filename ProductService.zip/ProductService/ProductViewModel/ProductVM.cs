﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProductViewModel
{
    public class ProductVM
    {
        private ObservableCollection<ProductServiceRef.Product> productList = null;

        public ProductVM()
        {
            ProductServiceRef.InventoryServiceClient client = new ProductServiceRef.InventoryServiceClient();
            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore
            };

            productList = JsonConvert.DeserializeObject<ObservableCollection<ProductServiceRef.Product>>(client.GetProductList(),settings);
        }
        public ObservableCollection<ProductServiceRef.Product> ProductList
        {
            get
            {
                return productList;
            }
        }
    }
}
