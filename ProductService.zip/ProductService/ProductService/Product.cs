﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ProductService
{ 
    [DataContract]
    public class Product
    {
       [DataMember]
       public int ProductId { get; set; }
        [DataMember]
        public String Name { get; set; }
        [DataMember]
        public int Cost { get; set; }
        [DataMember]
        public String DOP { get; set; }
       
    }
}