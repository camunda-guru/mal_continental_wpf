﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ProductService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IInventoryService" in both code and config file together.
    [ServiceContract]
    public interface IInventoryService
    {
        [OperationContract]
       // [WebGet(UriTemplate = "/products", ResponseFormat = WebMessageFormat.Json)]
        String GetProductList();
        [OperationContract]
        Product FindByProductId(int Id);
        [OperationContract]
        
        void AddNewProduct(Product product);
    }
}
