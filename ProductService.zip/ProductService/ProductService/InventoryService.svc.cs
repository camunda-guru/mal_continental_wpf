﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ProductService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "InventoryService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select InventoryService.svc or InventoryService.svc.cs at the Solution Explorer and start debugging.
    public class InventoryService : IInventoryService
    {
        public void AddNewProduct(Product product)
        {
            throw new NotImplementedException();
        }

       

        public Product FindByProductId(int Id)
        {
            throw new NotImplementedException();
        }

        public String GetProductList()
        {
            DataTable dt = ProductDAL.OracleConnector.GetProducts();
            long size = dt.Rows.Count;            
            
            return JsonConvert.SerializeObject(dt, Formatting.Indented); 
        }
    }
}
