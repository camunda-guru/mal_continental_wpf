namespace PagingControlProject.Custom_Control
{
    internal enum PageChanges
    {
        First,
        Previous,
        Current,
        Next,
        Last
    }
}