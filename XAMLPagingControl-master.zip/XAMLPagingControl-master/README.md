# XAML Paging & Sorting Control
A paging control based on http://www.codeproject.com/Articles/350447/WPF-Paging-in-DataGrid-ListBox by Nilay [M Joshi](http://www.codeproject.com/script/Membership/View.aspx?mid=5277189)

With support for Sorting!

Ready to use with MVVM ;)
