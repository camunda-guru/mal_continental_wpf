﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace MessageContractClient
{
    class Program
    {
        static void Main(string[] args)
        {
            PaymentServiceRef.PaymentClient client = new PaymentServiceRef.PaymentClient();
            PaymentServiceRef.User user = new PaymentServiceRef.User();
            user.UserId = 4242321;
            user.Password = "viki@123";
            try
            {
                Console.WriteLine(client.VerifyUser(user));
            }
            catch(FaultException ex)
            {
                Console.WriteLine(ex.Message);
            }

             foreach(PaymentServiceRef.Transaction tran in  client.GetTransactions())
             {
                 Console.WriteLine(tran.TransactionId);
             }

             try
             {
                 PaymentServiceRef.User response = client.GetUser("X5089538665801263e6AYtiqti", 242543);
                 Console.WriteLine(response.UserId);

             }
            catch(FaultException ex)
             {
                 Console.WriteLine(ex);
             }
             
                Console.ReadKey();
        }
    }
}
