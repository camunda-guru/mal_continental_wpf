﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Payment
/// </summary>
public class Payment:IPayment
{
	
    private User Verifyid(int id)
    {
        FileStream fs = new FileStream("UserData.txt", FileMode.Open, FileAccess.Read);
        StreamReader reader = new StreamReader(fs);
        reader.BaseStream.Seek(0, SeekOrigin.Begin);
        string str = reader.ReadLine();
                User user=new User();
        while (str != null)
        {
            str = reader.ReadLine();
            String[] userArr = str.Split('\t');
            if ((Convert.ToInt32(userArr[0]) == id))
            {
                user.UserId = Convert.ToInt32(userArr[0]);
                user.Password = userArr[1];   
                break;
            }

        }
        return user;

    }

    public bool VerifyUser(User user)
    {
        FileStream fs = new FileStream("UserData.txt", FileMode.Open, FileAccess.Read);
        StreamReader reader = new StreamReader(fs);
        reader.BaseStream.Seek(0, SeekOrigin.Begin);
        string str = reader.ReadLine();
        bool status=false;
        while (str != null)
        {
           str = reader.ReadLine();
           String[] userArr = str.Split('\t');
           if((Convert.ToInt32(userArr[0]) == user.UserId)&&(userArr[1].Equals(user.Password)))
            {
                status=true;
                break;
            }
           
        }
        return status;

        
    }

    public List<Transaction> GetTransactions()
    {
        

    }


    public PaymentResponse GetUser(PaymentRequest request)
    {
        FileStream fs = new FileStream("keys.txt", FileMode.Open, FileAccess.Read);
        StreamReader reader = new StreamReader(fs);
        reader.BaseStream.Seek(0, SeekOrigin.Begin);
        string str = reader.ReadLine();
        PaymentResponse response = new PaymentResponse();
        while (str != null)
        {
            str = reader.ReadLine();
            String[] keyArr = str.Split('\t');
            if (keyArr[0].Equals(request.AuthenticaionKey))
            {
               response.GetUserById= Verifyid(Convert.ToInt32(keyArr[1]));

                break;
            }

        }
        return response;


    }
}