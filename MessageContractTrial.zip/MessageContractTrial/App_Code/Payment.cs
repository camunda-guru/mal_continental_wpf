﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Web.Hosting;

/// <summary>
/// Summary description for Payment
/// </summary>
public class Payment:IPayment
{
    private static readonly ILog logger =
          LogManager.GetLogger(typeof(Payment));
    private User Verifyid(int id)
    {
        string filePath = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "App_Data", "UserData.txt");
        FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        StreamReader reader = new StreamReader(fs);
        reader.BaseStream.Seek(0, SeekOrigin.Begin);
        string str = reader.ReadLine();
                User user=new User();
        while (str != null)
        {
           
          
            String[] userArr = str.Split('-');
            if ((Convert.ToInt32(userArr[0]) == id))
            {
                user.UserId = Convert.ToInt32(userArr[0]);
                user.Password = userArr[1];
                break;
            }
            str = reader.ReadLine();
        }
        return user;

    }

    public bool VerifyUser(User user)
    {
        //GlobalContext.Properties["LogFileName"] = @"f:\\logs\\wcf.log";
        XmlConfigurator.Configure();
        string filePath = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "App_Data", "UserData.txt");
        FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        StreamReader reader = new StreamReader(fs);
        //reader.BaseStream.Seek(0, SeekOrigin.Begin);
        string str = reader.ReadLine();
        logger.Info(str);
        bool status=false;
        while (str != null)
        {
            
            
            String[] userArr = str.Split('-');
            if ((userArr[0] != null) && (userArr[1] != null))
            {
                logger.Info(userArr[0]);
                logger.Info(userArr[1]);
                if ((Convert.ToInt32(userArr[0]) == user.UserId) && (userArr[1].Equals(user.Password)))
                {
                    status = true;
                    break;
                }
            } 
            str = reader.ReadLine();

        }
        return status;

        
    }

    public List<Transaction> GetTransactions()
    {
        List<Transaction> transactionList = new List<Transaction>()
        {
            new Transaction{TransactionId=2364932,Mode="Cash",DOT=new DateTime(2018,1,1),Amount=2846},
            new Transaction{TransactionId=2376932,Mode="Cheque",DOT=new DateTime(2017,11,14),Amount=5000},
            new Transaction{TransactionId=8388932,Mode="Cash",DOT=new DateTime(2018,2,21),Amount=8000},
            new Transaction{TransactionId=2364932,Mode="Cash",DOT=new DateTime(2018,3,12),Amount=12846}

        };
        return transactionList;
    }


    public PaymentResponse GetUser(PaymentRequest request)
    {
        string filePath = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "App_Data", "keys.txt");
        FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        StreamReader reader = new StreamReader(fs);
        reader.BaseStream.Seek(0, SeekOrigin.Begin);
        string str = reader.ReadLine();
        PaymentResponse response = new PaymentResponse();
        while (str != null)
        {
            
            String[] keyArr = str.Split('-');
            if (!(keyArr[0].Equals(request.AuthenticaionKey)))
                //throw new FaultException<String>("Not Matching Key", "Error");
                str = reader.ReadLine();
            else 
            {
                response.GetUserById = Verifyid(Convert.ToInt32(keyArr[1]));
                break;
                
            }
           
        }
        return response;

        
    }
}