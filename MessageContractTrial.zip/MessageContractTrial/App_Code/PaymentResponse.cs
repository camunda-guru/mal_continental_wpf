﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;

/// <summary>
/// Summary description for PaymentResponse
/// </summary>
[MessageContract]
public class PaymentResponse
{
    [MessageBodyMember]
    public User GetUserById { get; set; }
}