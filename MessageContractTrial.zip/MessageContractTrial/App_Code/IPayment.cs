﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;

/// <summary>
/// Summary description for Payment
/// </summary>
[ServiceContract]
public interface IPayment
{
    [OperationContract]
    bool VerifyUser(User user);
     [OperationContract]
    List<Transaction> GetTransactions();
     [OperationContract]
     PaymentResponse GetUser(PaymentRequest request);


}