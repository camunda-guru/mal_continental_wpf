﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

/// <summary>
/// Summary description for User
/// </summary>
[DataContract]
public class User
{
    [DataMember]
    public int UserId { get; set; }
      [DataMember]
    public String Password { get; set; }

}