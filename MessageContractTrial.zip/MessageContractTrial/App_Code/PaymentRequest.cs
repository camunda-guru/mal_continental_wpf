﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Net.Security;
/// <summary>
/// Summary description for PaymentRequest
/// </summary>
[MessageContract]
public class PaymentRequest
{
    [MessageHeader(ProtectionLevel=ProtectionLevel.EncryptAndSign)]
    public String AuthenticaionKey { get; set; }
    [MessageBodyMember(ProtectionLevel=ProtectionLevel.Sign)]
    public long Id { get; set; }
}