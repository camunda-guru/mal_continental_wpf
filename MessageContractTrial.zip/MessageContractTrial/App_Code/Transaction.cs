﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

/// <summary>
/// Summary description for Transaction
/// </summary>
[DataContract]
public class Transaction
{
    [DataMember]
    public int TransactionId { get; set; }
     [DataMember]
    public long Amount { get; set; }
     [IgnoreDataMember]  
    public DateTime DOT { get; set; }
     [DataMember]
    public String Mode { get; set; }
}