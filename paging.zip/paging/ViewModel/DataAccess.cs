﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Data;
using DataStoreDllDemo;
using ViewModel;

namespace ViewModel

{
    /// <summary>
    /// Class that simulates a DataAccess module.
    /// </summary>
    public static class DataAccess
    {
        /// <summary>
        /// A list of products. This should be replaced by a database.
        /// </summary>
        private static ObservableCollection<UserViewModel> userList = new ObservableCollection<UserViewModel>();
        static DataAccess()
        {
            //Thread.Sleep(5000);
            DataTable dt = OracleConnector.FillDataGrid();

            foreach (DataRow row in dt.Rows)
            {

                //Thread.Sleep(100);
                UserViewModel obj = new UserViewModel();
                obj.FirstName = row["FIRST_NAME"].ToString();
                obj.LastName = row["LAST_NAME"].ToString();
                obj.Gender = row["GENDER"].ToString();
                obj.Address = row["ADDRESS"].ToString();
                obj.Password = row["PASSWORD"].ToString();
                obj.State = row["STATE"].ToString();
                obj.ProfilePhoto = row["PROFILE_PHOTO"].ToString();
                obj.Email = row["EMAIL"].ToString();
                obj.DOB = row["DOB"].ToString();
                userList.Add(obj);


            }


        }

        /// <summary>
        /// Gets the products.
        /// </summary>
        /// <param name="start">Zero-based index that determines the start of the products to be returned.</param>
        /// <param name="itemCount">Number of products that is requested to be returned.</param>
        /// <param name="sortColumn">Name of column or member that is the basis for sorting.</param>
        /// <param name="ascending">Indicates the sort direction to be used.</param>
        /// <param name="totalItems">Total number of products.</param>
        /// <returns>List of products.</returns>
        public static ObservableCollection<UserViewModel> GetProducts(int start, int itemCount, string sortColumn, bool ascending, out int totalItems)
        {
            totalItems = userList.Count;

            //ObservableCollection<UserViewModel> sortedProducts = new ObservableCollection<UserViewModel>();

            //// Sort the products. In reality, the items should be stored in a database and
            //// use SQL statements for sorting and querying items.
            //switch (sortColumn)
            //{
            //    case ("FirstName"):
            //        sortedProducts = new ObservableCollection<UserViewModel>
            //        (
            //            from p in userList
            //            orderby p.FirstName
            //            select p
            //        );
            //        break;
            //    case ("LastName"):
            //        sortedProducts = new ObservableCollection<UserViewModel>
            //        (
            //            from p in userList
            //            orderby p.LastName
            //            select p
            //        );
            //        break;
            //}

            //sortedProducts = ascending ? sortedProducts : new ObservableCollection<UserViewModel>(sortedProducts.Reverse());

            ObservableCollection<UserViewModel> filteredProducts = new ObservableCollection<UserViewModel>();

            for (int i = start; i < start + itemCount &&  i < totalItems; i++)
            {
                filteredProducts.Add(userList[i]);
            }

            return filteredProducts;
        }
    }
}
