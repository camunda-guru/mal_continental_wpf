﻿using DataStoreDllDemo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ViewModel
{
    public class SaveCommand : ICommand
    {
        

        public event EventHandler CanExecuteChanged
        {
            add {
                
                CommandManager.RequerySuggested += value;
            }
            remove {
            CommandManager.RequerySuggested -= value;}
        }



        public bool CanExecute(object parameter)
        {
            
            var cont_user = parameter as UserViewModel;
            return cont_user != null
             && !string.IsNullOrWhiteSpace(cont_user.FirstName)
                && !string.IsNullOrWhiteSpace(cont_user.LastName)
                && !string.IsNullOrWhiteSpace(cont_user.Email)
            && !string.IsNullOrWhiteSpace(cont_user.Address)
             && !string.IsNullOrWhiteSpace(cont_user.DOB)
              && !string.IsNullOrWhiteSpace(cont_user.State)
               && !string.IsNullOrWhiteSpace(cont_user.Password)
                 && !string.IsNullOrWhiteSpace(cont_user.Gender)
              && !string.IsNullOrWhiteSpace(cont_user.ProfilePhoto);
        }

        public void Execute(object parameter)
        {
            var cont_user = parameter as UserViewModel;
            CONT_USER obj = new CONT_USER();
            obj.firstName = cont_user.FirstName;
            obj.lastName = cont_user.LastName;
            obj.gender = cont_user.Gender;
            obj.email = cont_user.Email;
            obj.address = cont_user.Address;
            obj.dob = cont_user.DOB;
            obj.password = cont_user.Password;
            obj.profilePhoto = cont_user.ProfilePhoto;
            obj.state = cont_user.State;
            OracleConnector.addUser(obj);
            cont_user.FirstName = cont_user.LastName = cont_user.Email = cont_user.Address = cont_user.DOB = cont_user.State = cont_user.Password = cont_user.Gender = cont_user.ProfilePhoto = "";
        }
        

    }
}
