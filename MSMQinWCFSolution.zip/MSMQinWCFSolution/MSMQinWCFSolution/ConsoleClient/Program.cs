﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleClient.WishServiceRef;

namespace ConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Vishal", "Rahul", "Mayur" };
            string[] wishes = { "Prizes", "Books", ".NET Softwares" };
            
            WishClient[] objArray = new WishClient[names.Length];

            for (int i = 0; i < objArray.Length; i++)
            {
                objArray[i] = new WishClient();
                objArray[i].SayYourWish(names[i], wishes[i]);
            }
            Console.WriteLine("All Wishes sent successfully");
            Console.ReadLine();
        }
    }
}
