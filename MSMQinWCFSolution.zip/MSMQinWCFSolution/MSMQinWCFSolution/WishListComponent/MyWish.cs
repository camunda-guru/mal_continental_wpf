﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WishListComponent
{
    public class MyWish : IWish
    {
        public void SayYourWish(string wisherName, string yourWish)
        {
            Console.WriteLine("Client (Wisher): " + wisherName + " wish is :" + yourWish);
        }
    }
}
