﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ViewModel;

namespace MenuStack
{
    /// <summary>
    /// Interaction logic for EXIT.xaml
    /// </summary>
    public partial class EXIT : UserControl
    {

        public EXIT()
        {
            InitializeComponent();
            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += (o, ea) =>
            {
                
                Thread.Sleep(5000);
                //DataContext = new UserViewModel();            

            };
            worker.RunWorkerCompleted += (o, ea) =>
            {
                DataContext = new UserCollection();
                _busyIndicator.IsBusy = false;
            };
            _busyIndicator.IsBusy = true;
            worker.RunWorkerAsync();



        }

        
    }
       
    
}
