﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStoreDllDemo
{
    public class CONT_USER
    {
        public String firstName;
        public String lastName;
        public String dob;
        public String email;
        public String state;
        public String address;
        public String profilePhoto;
        public String password;
        public String gender;
        


    }
}
