﻿using DataStoreDllDemo;
using ViewModel.Library;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ViewModel
{
    public class UserViewModel : INotifyPropertyChanged
    {
        public CONT_USER cont_user = new CONT_USER();
        public event PropertyChangedEventHandler PropertyChanged;
        SaveCommand _saveCommand = new SaveCommand();

        

        public String FirstName
        {

            get
            {
                return cont_user.firstName;

            }
            set
            {
                if (cont_user.firstName != value)
                {
                    cont_user.firstName = value;
                    OnPropertyChanged("FirstName");
                }


            }
        }
        public String LastName
        {

            get
            {
                return cont_user.lastName;
            }
            set
            {
                if (cont_user.lastName != value)
                {
                    cont_user.lastName = value;
                    OnPropertyChanged("LastName");
                }

            }
        }
        public String DOB
        {

            get
            {
                return cont_user.dob;
            }
            set
            {
                if (cont_user.dob != value)
                {
                    cont_user.dob = value;
                    OnPropertyChanged("DOB");
                }

            }
        }
        public String Gender
        {
            get
            {
                return cont_user.gender;
            }
            set
            {
                if (cont_user.gender != value)
                {
                    cont_user.gender = value;
                    OnPropertyChanged("Gender");
                }

            }
        }
        public String State
        {
            get
            {
                return cont_user.state;
            }
            set
            {
                if (cont_user.state != value)
                {
                    cont_user.state = value;
                    OnPropertyChanged("State");
                }

            }
        }
        public String Email
        {
            get
            {
                return cont_user.email;
            }
            set
            {
                if (cont_user.email != value)
                {
                    cont_user.email = value;
                    OnPropertyChanged("Email");
                }

            }
        }
        public String Address
        {
            get
            {
                return cont_user.address;
            }
            set
            {
                if (cont_user.address != value)
                {
                    cont_user.address = value;
                    OnPropertyChanged("Address");
                }

            }
        }
        public String Password
        {
            get
            {
                return cont_user.password;
            }
            set
            {
                if (cont_user.password != value)
                {
                    cont_user.password = value;
                    OnPropertyChanged("Password");
                }

            }
        }
        public String ProfilePhoto
        {
            get
            {
                return cont_user.profilePhoto;
            }
            set
            {
                if (cont_user.profilePhoto != value)
                {
                    cont_user.profilePhoto = value;
                    OnPropertyChanged("ProfilePhoto");
                }

            }
        }




        protected void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        public SaveCommand SaveCommand
        {
            get { return _saveCommand; }
        }


        
    }
}
