﻿namespace ViewModel.Library
{
    public interface ISortable
    {
        void Sort(string propertyName, string direction);
    }
}
