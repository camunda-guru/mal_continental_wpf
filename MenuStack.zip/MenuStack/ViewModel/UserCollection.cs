﻿using DataStoreDllDemo;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ViewModel
{
    public class UserCollection
    {
        private  ObservableCollection<UserViewModel> userList = new ObservableCollection<UserViewModel>();

        public UserCollection()
        {
            //Thread.Sleep(5000);
            DataTable dt = OracleConnector.FillDataGrid();

            foreach(DataRow row in dt.Rows)
            {
                //Thread.Sleep(100);
                UserViewModel obj = new UserViewModel();
                obj.FirstName = row["FIRST_NAME"].ToString();
                obj.LastName = row["LAST_NAME"].ToString();
                obj.Gender = row["GENDER"].ToString();
                obj.Address = row["ADDRESS"].ToString();
                obj.Password = row["PASSWORD"].ToString();
                obj.State = row["STATE"].ToString();
                obj.ProfilePhoto = row["PROFILE_PHOTO"].ToString();
                obj.Email = row["EMAIL"].ToString();
                obj.DOB = row["DOB"].ToString();
                userList.Add(obj);


            }
           

        }

        public ObservableCollection<UserViewModel> UserList
        {
            get
            {
                return this.userList;
            }
        }



    }
}
