﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGrid
{
    class AuthorCollection : CollectionBase
    {
        /// <summary>  
        /// List of Authors  
        /// </summary>  
        /// <returns></returns>  
        public List<Author> LoadAuthors()
        {
            List<Author> authors = new List<Author>();
            authors.Add(new Author()
            {
                ID = 101,
                Name = "Mahesh Chand",
                BookTitle = "Graphics Programming with GDI+",
                DOB = new DateTime(1975, 2, 23),
                IsMVP = false,
                City = "Philadelphia",
                Country = "USA",
                Zip = 19060
            });
            authors.Add(new Author()
            {
                ID = 201,
                Name = "Mike Gold",
                BookTitle = "Programming C#",
                DOB = new DateTime(1982, 4, 12),
                IsMVP = true,
                City = "Austin",
                Country = "USA",
                Zip = 23020
            });
            authors.Add(new Author()
            {
                ID = 244,
                Name = "Praveen Kumar",
                BookTitle = "ADO.NET Development",
                DOB = new DateTime(1985, 9, 11),
                IsMVP = true,
                City = "New Delhi",
                Country = "India",
                Zip = 201301
            });

            return authors;
        }
    }
}
