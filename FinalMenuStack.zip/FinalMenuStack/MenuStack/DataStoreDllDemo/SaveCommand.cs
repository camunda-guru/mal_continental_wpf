﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DataStoreDllDemo
{
    public class SaveCommand : ICommand
    {
        

        public event EventHandler CanExecuteChanged
        {
            add {
                
                CommandManager.RequerySuggested += value;
            }
            remove {
            CommandManager.RequerySuggested -= value;}
        }



        public bool CanExecute(object parameter)
        {
            var cont_user = parameter as CONT_USER;
            return cont_user != null
             && !string.IsNullOrWhiteSpace(cont_user.FirstName)
                && !string.IsNullOrWhiteSpace(cont_user.LastName)
                && !string.IsNullOrWhiteSpace(cont_user.Email)
            && !string.IsNullOrWhiteSpace(cont_user.Address)
             && !string.IsNullOrWhiteSpace(cont_user.DOB)
              && !string.IsNullOrWhiteSpace(cont_user.State)
               && !string.IsNullOrWhiteSpace(cont_user.Password)
                 && !string.IsNullOrWhiteSpace(cont_user.Gender)
              && !string.IsNullOrWhiteSpace(cont_user.ProfilePhoto);
        }

        public void Execute(object parameter)
        {
            var cont_user = parameter as CONT_USER;
            OracleConnector.addUser(cont_user);
            cont_user.FirstName = cont_user.LastName = cont_user.Email = cont_user.Address = cont_user.DOB = cont_user.State = cont_user.Password = cont_user.Gender = cont_user.ProfilePhoto = "";
        }
        

    }
}
