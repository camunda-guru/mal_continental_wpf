﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MenuStack
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ShowControl(Control control, string title)
        {

            control.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
            control.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;

            control.Width = double.NaN;
            control.Height = double.NaN;

            gvContainer.Children.Clear();
            gvContainer.Children.Add(control);


            lblTitle.Content = title;
        }
        //private void ButtonClick(object sender, RoutedEventArgs e)
        //{
        //    // Get the current button.
        //    try
        //    {
        //        Button cmd = (Button)e.OriginalSource;
        //        //MessageBox.Show(cmd.Content.ToString());
        //        //Create an instance of the window named
        //        //by the current button.
        //        Type type = this.GetType();
        //        Assembly assembly = type.Assembly;
        //        Window win = (Window)assembly.CreateInstance(
        //            type.Namespace + "." + cmd.Content);

        //        // Show the window.
        //        win.ShowDialog();
        //    }
        //    catch(NullReferenceException obj)
        //    {

        //    }
        //    catch(InvalidCastException invalid)
        //    {
        //        MessageBox.Show("Raise Only Button Events");

        //    }
        //}

        private void PROJECTS_Click(object sender, RoutedEventArgs e)
        {
            

            ShowControl(new Projects(), "Projects");
        }
        private void CMP_Click(object sender, RoutedEventArgs e)
        {
            ShowControl(new CMP(), "CMP");
        }
        private void VARIANT_Click(object sender, RoutedEventArgs e)
        {
            ShowControl(new VARIANT_MANAGER(), "VARIANT MANAGER");
        }
        private void SCHEMATIC_Click(object sender, RoutedEventArgs e)
        {
            ShowControl(new SCHEMATIC(), "SCHEMATIC");
        }
        private void CURRENTSETTINGS_Click(object sender, RoutedEventArgs e)
        {
            ShowControl(new CURRENT_SETTINGS(), "CURRENT SETTINGS");
        }
        private void SYSTEMSETTINGS_Click(object sender, RoutedEventArgs e)
        {
            //ShowControl(new SYSTEM_(), "VARIANT MANAGER");
        }
        private void EXIT_Click(object sender, RoutedEventArgs e)
        {
            ShowControl(new EXIT(), "EXIT");
        }

     
    }
}
