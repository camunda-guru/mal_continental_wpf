﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCFPerCallClient
{
    class Program
    {
        static void Main(string[] args)
        {
            CallServiceRef.RandomNumberServiceClient sclient = new CallServiceRef.RandomNumberServiceClient();
            Console.WriteLine(sclient.Increment());
            Console.WriteLine(sclient.Increment());
            Console.WriteLine(sclient.GenerateRandomNumber());
            Console.WriteLine(sclient.GenerateRandomNumber());

            CallServiceRef.RandomNumberServiceClient newclient = new CallServiceRef.RandomNumberServiceClient();
            Console.WriteLine(newclient.Increment());
            Console.WriteLine(newclient.Increment());
            Console.WriteLine(newclient.GenerateRandomNumber());
            Console.WriteLine(newclient.GenerateRandomNumber());

            Console.Read();
        }
    }
}
