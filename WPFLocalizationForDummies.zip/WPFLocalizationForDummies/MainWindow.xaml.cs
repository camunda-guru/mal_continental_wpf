﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFLocalizationForDummies
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ru-RU");
            //Title = WPFLocalizationForDummies.Properties.Resources.Title;
            //var culture = new System.Globalization.CultureInfo("ru-RU");
            //Thread.CurrentThread.CurrentCulture = culture;
            //var title = Resources;
            //CultureInfo tCulture = new CultureInfo("");
           
            //Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("fr-FR");
           // Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("fr-FR");
        }
    }
}
