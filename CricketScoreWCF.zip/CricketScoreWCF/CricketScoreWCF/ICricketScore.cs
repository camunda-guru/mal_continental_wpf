﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CricketScoreWCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICricketScore" in both code and config file together.
    [ServiceContract]
    public interface ICricketScore
    {
        [OperationContract]
        String GetCSKScore();
        [OperationContract]
        String[] GetCSKPlayerList();
        [OperationContract]
        [WebGet(UriTemplate = "/Stadium/{Code}")]
        String GetStadiumStatus(String Code);
    }
}
