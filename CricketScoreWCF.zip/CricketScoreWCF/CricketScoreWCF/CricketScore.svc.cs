﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace CricketScoreWCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CricketScore" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CricketScore.svc or CricketScore.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CricketScore : ICricketScore
    {
        public string[] GetCSKPlayerList()
        {
            String[] playerList = { "MSD", "Rahul", "XYZ" };
            return playerList;
        }

        public string GetCSKScore()
        {
            return (String.Format("21 April 2018 CSK score is {0}", 258));
        }

        public string GetStadiumStatus(String Code)
        {
            return (String.Format("Stadium {0} full", Code));
        }
    }
}
