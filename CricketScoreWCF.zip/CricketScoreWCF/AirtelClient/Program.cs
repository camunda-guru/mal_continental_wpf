﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirtelClient
{
    class Program
    {
        static void Main(string[] args)
        {

            CricketScoreRef.CricketScoreClient client = new CricketScoreRef.CricketScoreClient();
            foreach(String name in client.GetCSKPlayerList())
            {
                Console.WriteLine(name);
            }
            Console.WriteLine(client.GetCSKScore());
            Console.ReadKey();
           
        }
    }
}
