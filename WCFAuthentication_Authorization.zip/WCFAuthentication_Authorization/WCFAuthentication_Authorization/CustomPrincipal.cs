﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace WCFAuthentication_Authorization
{
    public class CustomPrincipal : IPrincipal
    {
        IIdentity _identity;
        private string[] _roles;
        public CustomPrincipal(IIdentity identity)
        {
            this._identity = identity;
        }

        public IIdentity Identity
        {
            get { return this._identity; }
        }

        public bool IsInRole(string role)
        {
            if (this._identity.Name == "test")
                _roles = new string[1] { "ADMIN" };
            else
                _roles = new string[1] { "USER" };
            return _roles.Contains(role);
        }
    }
}