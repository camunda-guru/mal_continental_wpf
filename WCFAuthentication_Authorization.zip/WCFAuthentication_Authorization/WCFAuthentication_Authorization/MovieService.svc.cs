﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.ServiceModel;
using System.Text;

namespace WCFAuthentication_Authorization
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MovieService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MovieService.svc or MovieService.svc.cs at the Solution Explorer and start debugging.
    public class MovieService : IMovieService
    {
        [PrincipalPermission(SecurityAction.Demand, Role = "ADMIN")]
        public Movie GetByDirector(string Name)
        {
            return GetMovieList().Find(x => x.Name.Equals(Name));

        }
        [PrincipalPermission(SecurityAction.Demand, Role = "ADMIN")]
        public List<Movie> GetMovieList()
        {
            List<Movie> movieList = new List<Movie>()
            {
                new Movie{MovieId=1,Name="Bahubali",Director="RajaMouli"},
                new Movie{MovieId=2,Name="Robo 2.0",Director="Shankar"},
                new Movie{MovieId=3,Name="Mercury",Director="Karthik"},
                new Movie{MovieId=4,Name="Kaala",Director="Atlee"}
            };
            return movieList;

        }
    }
}
