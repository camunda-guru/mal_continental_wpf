﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WCFAuthentication_Authorization
{
    [DataContract]
    public class Movie
    {
        [DataMember]
        public int MovieId { get; set; }
        [DataMember]
        public String Name { get; set; }
        [DataMember]
        public DateTime ReleaseDate { get; set; }
        [DataMember]
        public String Director { get; set; }
    }
}