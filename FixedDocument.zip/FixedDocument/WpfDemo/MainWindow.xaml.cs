﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Xps.Packaging;

namespace WpfDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            XpsDocument document1= new XpsDocument(@"C:\Users\Balasubramaniam\Documents\coursecontent.xps", System.IO.FileAccess.Read);
            documentViewer1.Document = document1.GetFixedDocumentSequence();
            //documentViewer1.Height = 300;
            //documentViewer1.Width = 300;
        }
    }
}
