﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace Authentication_AuthorizationClient
{
    class Program
    {
        static void Main(string[] args)
        {
            MovieServiceRef.MovieServiceClient client = new MovieServiceRef.MovieServiceClient();
            client.ClientCredentials.UserName.UserName = "test";
            client.ClientCredentials.UserName.Password = "test123";
            //client.ClientCredentials.ServiceCertificate.Authentication.CertificateValidationMode =
//System.ServiceModel.Security.X509CertificateValidationMode.None;
            Console.WriteLine(client.GetMovieList().Count());
            Console.ReadKey();
        }
    }
}
